# Cohere Impact Hub

Cohere Impact Hub is a revolutionary social impact platform that seamlessly connects **NGOs**, **Volunteers**, and **Donors** in a unified ecosystem designed to maximize community impact. With real-time verified data, GPS-backed impact proofs, and a dynamic resource-sharing marketplace, Cohere drives meaningful change across the nation.

## 🚀 Key Features

* **Unified Dashboards:** Dedicated experiences for NGOs, Volunteers/Donors, and System Administrators.
* **Live Impact Map:** A dynamic, localized overview of upcoming, ongoing, and past charitable events spanning nationwide.
* **Stringent Verification System:** To prevent fraudulent activities, all NGOs must undergo a rigorous approval process. Post-event proofs require strictly verified GPS coordinates submitted within 24 hours.
* **Community Feed:** A Twitter-style localized timeline allowing NGOs to broadcast initiatives and requests securely.
* **Volunteer Matchmaking:** Real-time pairing of active resource needs with capable volunteers nearby.
* **NGO Collaboration Tools:** Specialized in-platform chat and integrated collaboration tools to merge NGO efforts for maximum efficiency.
* **Instant Donations:** One-click supply and financial donation options embedded securely at the event level.

## 🛠️ Tech Stack

* **Frontend:** React + Vite
* **Styling:** Tailwind CSS + custom glassmorphic aesthetics
* **Icons:** Lucide-React
* **Mapping:** Leaflet.js
* **Animations:** Framer Motion

## 📦 Local Setup Instructions

1. **Clone the repository:**
   ```bash
   git clone https://github.com/Svizzcodes/Cohere.git
   cd Cohere
   ```
2. **Install dependencies:**
   ```bash
   npm install
   ```
3. **Start the development server:**
   ```bash
   npm run dev
   ```

## 🔐 Security & Governance

Cohere takes platform integrity seriously. Users are strictly segregated by roles (`admin`, `ngo`, `donor`, `volunteer`), with admin dashboards governing the absolute verification state of NGOs, resources, and impact proofs.

---
*Built to bring communities together.*
