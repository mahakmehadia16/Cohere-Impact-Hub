import { useState } from 'react';
import { motion } from 'framer-motion';
import { Users, Briefcase, CheckCircle, Clock, Award, FileText, Lightbulb } from 'lucide-react';
import { Navbar } from '@/components/Navbar';
import { Button } from '@/components/ui/button';
import { useAppStore } from '@/lib/store';
import { toast } from 'sonner';
import { CountUp } from '@/components/CountUp';
import { DayPicker } from 'react-day-picker';
import 'react-day-picker/dist/style.css';

const QUOTES = [
  "Volunteers do not necessarily have the time; they just have the heart. – Elizabeth Andrew",
  "The best way to find yourself is to lose yourself in the service of others. – Mahatma Gandhi",
  "As you grow older, you will discover that you have two hands: one for helping yourself, the other for helping others. – Audrey Hepburn",
  "Volunteers are the only human beings on the face of the earth who reflect this nation's compassion. – Erma Bombeck"
];

export default function VolunteerDashboard() {
  const { currentUser, volunteerApps, events, certificates, issueCertificate, ngos, applyVolunteer } = useAppStore();
  if (!currentUser) return null;

  const [quote] = useState(() => QUOTES[Math.floor(Math.random() * QUOTES.length)]);
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date());
  const [calDialog, setCalDialog] = useState<any>(null);

  const myApps = volunteerApps.filter(a => a.volunteerId === currentUser.id);
  const accepted = myApps.filter(a => a.status === 'accepted').length;
  const completed = myApps.filter(a => a.status === 'completed').length;
  const myCerts = certificates.filter(c => c.userId === currentUser.id);

  // Suggested opportunities (campaigns/needs matching user skills)
  const suggested = events.filter(e => e.status === 'upcoming').slice(0, 4);

  const handleQuickApply = (post: typeof events[0]) => {
    const ngo = ngos.find(n => n.id === post.ngoId);
    if (!ngo) return;
    applyVolunteer({
      volunteerId: currentUser.id,
      volunteerName: currentUser.name,
      ngoId: ngo.id,
      ngoName: ngo.name,
      role: 'Volunteer',
      skills: currentUser.skills || [],
    });
    toast.success(`Applied to ${ngo.name}!`);
  };

  const generateCert = async () => {
    if (completed === 0) { toast.error("You must have completed at least one verified assignment to generate a certificate."); return; }
    try {
      toast.info('Generating official PDF certificate...');
      const res = await fetch('/api/certificates/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: currentUser.id, name: currentUser.name, type: 'volunteer', description: `Completed ${completed} verified volunteer assignments` })
      });
      if (!res.ok) throw new Error('Generate failed');
      const blob = await res.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `Cohere_Certificate_${currentUser.name}.pdf`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      
      issueCertificate({ userId: currentUser.id, userName: currentUser.name, type: 'volunteer', description: `Completed ${completed} verified volunteer assignments`, ngoName: 'Cohere Platform' });
      toast.success('Certificate downloaded successfully!');
    } catch(e) {
      toast.error('Failed to generate certificate.');
    }
  };

  const selectedDateEvents = events.filter(e => {
    if (!selectedDate) return false;
    const evDate = new Date(e.date);
    return evDate.getDate() === selectedDate.getDate() && evDate.getMonth() === selectedDate.getMonth() && evDate.getFullYear() === selectedDate.getFullYear();
  });

  return (
    <div className="min-h-screen bg-yellow-400 dark:bg-yellow-600 text-slate-900 dark:text-slate-50">
      <Navbar />
      <div className="container mx-auto px-4 pt-24 pb-12">
        <div className="mb-8">
          <h1 className="font-display text-2xl font-bold">Volunteer Dashboard</h1>
          <p className="text-base font-medium">Welcome, {currentUser.name}</p>
          {currentUser.skills && (
            <div className="flex gap-2 mt-2 flex-wrap">
              {currentUser.skills.map(s => (
                <span key={s} className="text-xs px-2 py-1 rounded-full bg-primary/10 text-primary">{s}</span>
              ))}
            </div>
          )}
        </div>

        <div className="mb-8 p-6 rounded-xl bg-white dark:bg-slate-900 text-yellow-600 dark:text-yellow-500 shadow-xl flex items-center justify-center text-center">
          <p className="italic font-bold text-xl">&quot;{quote}&quot;</p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          {[
            { label: 'Applications', value: myApps.length, icon: Briefcase },
            { label: 'Accepted', value: accepted, icon: CheckCircle },
            { label: 'Completed', value: completed, icon: Award },
            { label: 'Certificates', value: myCerts.length, icon: FileText },
          ].map(s => (
            <div key={s.label} className="bg-white dark:bg-slate-900 p-6 rounded-xl text-slate-900 dark:text-white shadow-xl">
              <s.icon className="w-6 h-6 text-yellow-500 dark:text-yellow-400 mb-3" />
              <div className="text-3xl font-display font-bold"><CountUp end={s.value} /></div>
              <p className="text-sm font-semibold text-slate-500 dark:text-slate-400">{s.label}</p>
            </div>
          ))}
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          {/* My Applications */}
          <div className="bg-white dark:bg-slate-900 text-slate-900 dark:text-white rounded-xl shadow-xl p-6">
            <h2 className="font-display text-lg font-semibold mb-4">My Applications</h2>
            {myApps.length === 0 ? <p className="text-sm text-muted-foreground">No applications yet. Check suggested opportunities!</p> : (
              <div className="space-y-3">
                {myApps.map(a => (
                  <div key={a.id} className="flex items-center justify-between p-4 rounded-lg bg-slate-50 dark:bg-slate-800">
                    <div>
                      <p className="font-medium text-sm">{a.role}</p>
                      <p className="text-xs text-muted-foreground">{a.ngoName}</p>
                    </div>
                    <span className={`text-xs px-2 py-1 rounded-full ${
                      a.status === 'accepted' ? 'bg-success/10 text-success' :
                      a.status === 'applied' ? 'bg-info/10 text-info' : 'bg-muted text-muted-foreground'
                    }`}>{a.status}</span>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="space-y-6">
            {/* Suggested */}
            <div className="bg-white dark:bg-slate-900 text-slate-900 dark:text-white rounded-xl shadow-xl p-6">
              <h2 className="font-display text-lg font-semibold mb-4 flex items-center gap-2">
                <Lightbulb className="w-5 h-5 text-warning" /> Suggested Opportunities
              </h2>
              {suggested.map(p => (
                <div key={p.id} className="p-3 rounded-lg bg-slate-50 dark:bg-slate-800 mb-2 flex items-center justify-between">
                  <div className="flex-1 mr-3">
                    <p className="text-sm font-medium">{p.ngoName}</p>
                    <p className="text-xs text-muted-foreground line-clamp-1">{p.title}</p>
                  </div>
                  <Button size="sm" variant="outline" onClick={() => handleQuickApply(p)}>Apply</Button>
                </div>
              ))}
            </div>

            {/* Certificates */}
            <div className="glass-card p-6">
              <h2 className="font-display text-lg font-semibold mb-4 flex items-center gap-2"><FileText className="w-5 h-5" /> Certificates</h2>
              <Button variant="secondary" className="bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-white hover:bg-slate-200 dark:hover:bg-slate-700 mb-3">Generate Service Certificate</Button>
              {myCerts.map(c => (
                <div key={c.id} className="p-4 rounded-lg bg-slate-50 dark:bg-slate-800 mb-2">
                  <p className="text-sm font-medium">{c.description}</p>
                  <p className="text-xs text-muted-foreground">{c.issuedAt.toLocaleDateString()}</p>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Huge Calendar Section */}
        <div className="mt-8 bg-white dark:bg-slate-900 text-slate-900 dark:text-white rounded-xl shadow-xl p-6 border border-slate-200 dark:border-slate-800 overflow-hidden relative">
          <h2 className="font-display text-2xl font-bold mb-6 flex items-center gap-2"><Clock className="w-6 h-6 text-yellow-500" /> Event Schedule & Calendar</h2>
          <div className="grid lg:grid-cols-2 gap-8">
            <div className="flex justify-center p-4 bg-slate-50 dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700">
              <style>{`.rdp { --rdp-cell-size: 55px; --rdp-accent-color: #eab308; /* yellow-500 */ } .rdp-day_selected, .rdp-day_selected:focus-visible, .rdp-day_selected:hover { background-color: var(--rdp-accent-color); color: white; }`}</style>
              <DayPicker 
                mode="single" 
                selected={selectedDate} 
                onSelect={setSelectedDate} 
                className="scale-[1.1] md:scale-[1.2] origin-top"
              />
            </div>
            <div>
              <h3 className="text-xl font-bold mb-4">Events on {selectedDate?.toLocaleDateString() || 'Selected Date'}</h3>
              <div className="space-y-4">
                {selectedDateEvents.map(ev => (
                  <div key={ev.id} className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800 border-l-4 border-yellow-500 hover:shadow-md transition-all cursor-pointer" onClick={() => handleQuickApply(ev)}>
                    <h4 className="font-bold text-lg">{ev.title}</h4>
                    <p className="text-sm font-semibold text-slate-500 mb-2">{ev.ngoName} • {ev.location}</p>
                    <p className="text-sm line-clamp-2 text-slate-600 dark:text-slate-300">{ev.content}</p>
                    <div className="mt-4">
                      <span className="text-xs font-bold px-3 py-1.5 bg-yellow-500 text-white rounded-full">Click to Apply / Join</span>
                    </div>
                  </div>
                ))}
                {selectedDateEvents.length === 0 && (
                  <div className="text-center p-8 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl">
                    <p className="text-slate-500 font-medium">No events scheduled for this day.</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
