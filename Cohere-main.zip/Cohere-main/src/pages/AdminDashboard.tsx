import { motion } from 'framer-motion';
import { Shield, CheckCircle, XCircle, Users, Package, TrendingUp, AlertTriangle } from 'lucide-react';
import { Navbar } from '@/components/Navbar';
import { Button } from '@/components/ui/button';
import { useAppStore } from '@/lib/store';
import { toast } from 'sonner';
import { CountUp } from '@/components/CountUp';

export default function AdminDashboard() {
  const { ngos, approveNGO, rejectNGO, getStats, resources, volunteerApps, proofs, verifyProof } = useAppStore();
  const stats = getStats();
  const pendingNGOs = ngos.filter(n => n.status === 'pending');
  const pendingProofs = proofs.filter(p => p.status === 'pending');

  return (
    <div className="min-h-screen bg-red-600 dark:bg-red-900 text-white">
      <Navbar />
      <div className="container mx-auto px-4 pt-24 pb-12">
        <div className="flex items-center gap-3 mb-8">
          <div className="w-12 h-12 rounded-xl bg-white flex items-center justify-center shadow-lg"><Shield className="w-6 h-6 text-red-600" /></div>
          <div><h1 className="font-display text-3xl font-bold">Admin Panel</h1><p className="text-base text-white/90">System overview & management</p></div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          {[
            { label: 'Active NGOs', value: stats.ngosActive, icon: Users },
            { label: 'Total Resources', value: resources.length, icon: Package },
            { label: 'Volunteers', value: stats.volunteersEngaged, icon: Users },
            { label: 'Pending Approvals', value: pendingNGOs.length, icon: AlertTriangle },
          ].map(s => (
            <div key={s.label} className="bg-white dark:bg-slate-900 p-6 rounded-xl text-slate-900 dark:text-white shadow-xl">
              <s.icon className="w-6 h-6 text-red-600 dark:text-red-400 mb-3" />
              <div className="text-3xl font-display font-bold"><CountUp end={s.value} /></div>
              <p className="text-sm font-semibold text-slate-500 dark:text-slate-400">{s.label}</p>
            </div>
          ))}
        </div>

        {/* Pending NGOs */}
        <div className="bg-white dark:bg-slate-900 text-slate-900 dark:text-white rounded-xl shadow-xl p-6 mb-6">
          <h2 className="font-display text-xl font-bold mb-4">Pending NGO Verifications ({pendingNGOs.length})</h2>
          {pendingNGOs.length === 0 ? (
            <p className="text-base text-slate-500">No pending verifications.</p>
          ) : (
            <div className="space-y-4">
              {pendingNGOs.map(ngo => (
                <div key={ngo.id} className="flex items-center justify-between p-4 rounded-lg bg-slate-50 dark:bg-slate-800 border-l-4 border-l-red-500">
                  <div>
                    <h3 className="font-bold text-lg">{ngo.name}</h3>
                    <p className="text-sm text-slate-600 dark:text-slate-300">{ngo.description || 'No description'}</p>
                    <p className="text-xs font-semibold text-slate-500 mt-1">{ngo.location}</p>
                  </div>
                  <div className="flex gap-2">
                    <Button size="sm" onClick={() => { approveNGO(ngo.id); toast.success(`${ngo.name} approved`); }}>
                      <CheckCircle className="w-4 h-4 mr-1" /> Approve
                    </Button>
                    <Button variant="destructive" size="sm" onClick={() => { rejectNGO(ngo.id); toast.info(`${ngo.name} rejected`); }}>
                      <XCircle className="w-4 h-4 mr-1" /> Reject
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Pending Proofs */}
        <div className="bg-white dark:bg-slate-900 text-slate-900 dark:text-white rounded-xl shadow-xl p-6 mb-6">
          <h2 className="font-display text-xl font-bold mb-4">Pending Proofs ({pendingProofs.length})</h2>
          {pendingProofs.length === 0 ? (
            <p className="text-base text-slate-500">No pending proofs.</p>
          ) : (
            <div className="space-y-3">
              {pendingProofs.map(p => (
                <div key={p.id} className="flex items-center justify-between p-4 rounded-lg bg-slate-50 dark:bg-slate-800 border-l-4 border-l-red-500">
                  <div>
                    <p className="font-bold text-lg">{p.ngoName}: {p.description}</p>
                    <p className="text-sm text-slate-500 font-semibold">{p.location} · {p.timestamp.toLocaleDateString()}</p>
                  </div>
                  <Button size="sm" onClick={() => { verifyProof(p.id); toast.success('Proof verified'); }}>Verify</Button>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* All NGOs */}
        <div className="bg-white dark:bg-slate-900 text-slate-900 dark:text-white rounded-xl shadow-xl p-6">
          <h2 className="font-display text-xl font-bold mb-4">All NGOs ({ngos.length})</h2>
          <div className="space-y-2">
            {ngos.map(ngo => (
              <div key={ngo.id} className="flex items-center justify-between p-4 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 rounded-lg bg-red-100 flex items-center justify-center text-red-600 text-sm font-bold">{ngo.name[0]}</div>
                  <div>
                    <p className="font-bold text-base">{ngo.name}</p>
                    <p className="text-sm font-medium text-slate-500">{ngo.location}</p>
                  </div>
                </div>
                <span className={`text-xs px-2 py-1 rounded-full font-medium ${
                  ngo.status === 'verified' ? 'bg-success/10 text-success' :
                  ngo.status === 'pending' ? 'bg-warning/10 text-warning' : 'bg-destructive/10 text-destructive'
                }`}>{ngo.status}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
