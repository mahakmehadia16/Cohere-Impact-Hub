import { useState } from 'react';
import { motion } from 'framer-motion';
import { Heart, Package, Award, TrendingUp, FileText, Plus } from 'lucide-react';
import { Navbar } from '@/components/Navbar';
import { Button } from '@/components/ui/button';
import { useAppStore } from '@/lib/store';
import { toast } from 'sonner';
import { CountUp } from '@/components/CountUp';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import type { ResourceCategory } from '@/lib/store';

const QUOTES = [
  "No one has ever become poor by giving. – Anne Frank",
  "The meaning of life is to find your gift. The purpose of life is to give it away. – Pablo Picasso",
  "We make a living by what we get, but we make a life by what we give. – Winston Churchill",
  "It's not how much we give but how much love we put into giving. – Mother Teresa"
];

export default function DonorDashboard() {
  const { currentUser, resources, certificates, addResource, events, issueCertificate } = useAppStore();
  const [showAdd, setShowAdd] = useState(false);
  const [activeTab, setActiveTab] = useState<'overview'|'food'>('overview');
  const [newRes, setNewRes] = useState({ title: '', description: '', category: 'food' as ResourceCategory, quantity: 1, unit: 'items', location: '', expiry: '' });
  const [quote] = useState(() => QUOTES[Math.floor(Math.random() * QUOTES.length)]);

  if (!currentUser) return null;

  const myResources = resources.filter(r => r.donorId === currentUser.id);
  const myCerts = certificates.filter(c => c.userId === currentUser.id);
  const totalDonated = myResources.length;
  const claimed = myResources.filter(r => r.status === 'claimed' || r.status === 'delivered').length;

  const handleAdd = () => {
    addResource({ ...newRes, donorId: currentUser.id, donorName: currentUser.name, lat: 19 + Math.random() * 10, lng: 73 + Math.random() * 7 });
    toast.success('Resource posted!');
    setShowAdd(false);
  };

  const generateCertificate = async () => {
    try {
      toast.info('Generating official PDF certificate...');
      const res = await fetch('/api/certificates/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: currentUser.id, name: currentUser.name, type: 'donation', description: `Donated ${totalDonated} resources through Cohere platform` })
      });
      if (!res.ok) throw new Error('Generate failed');
      const blob = await res.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `Cohere_Certificate_${currentUser.name}.pdf`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      
      issueCertificate({ userId: currentUser.id, userName: currentUser.name, type: 'donation', description: `Donated ${totalDonated} resources through Cohere platform`, ngoName: 'Cohere Platform' });
      toast.success('Certificate downloaded successfully!');
    } catch(e) {
      toast.error('Failed to generate certificate.');
    }
  };

  // Suggested campaigns
  const suggestedCampaigns = events.filter(e => e.status === 'upcoming').slice(0, 3);

  return (
    <div className="min-h-screen bg-blue-600 dark:bg-blue-900 text-white">
      <Navbar />
      <div className="container mx-auto px-4 pt-24 pb-12">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="font-display text-2xl font-bold">Donor Dashboard</h1>
            <p className="text-base text-white/90">Welcome, {currentUser.name}</p>
          </div>
          <Dialog open={showAdd} onOpenChange={setShowAdd}>
            <DialogTrigger asChild>
              <Button className="bg-blue-600 hover:bg-blue-700 text-white"><Plus className="w-4 h-4 mr-2" /> Donate</Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader><DialogTitle>Post a Donation</DialogTitle></DialogHeader>
              <div className="space-y-4 mt-4">
                <div><Label>Title</Label><Input value={newRes.title} onChange={e => setNewRes(p => ({ ...p, title: e.target.value }))} /></div>
                <div><Label>Description</Label><Textarea value={newRes.description} onChange={e => setNewRes(p => ({ ...p, description: e.target.value }))} /></div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label>Category</Label>
                    <select className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm" value={newRes.category} onChange={e => setNewRes(p => ({ ...p, category: e.target.value as ResourceCategory }))}>
                      <option value="food">Food</option><option value="clothes">Clothes</option><option value="essentials">Essentials</option><option value="funds">Funds</option>
                    </select>
                  </div>
                  <div><Label>Quantity</Label><Input type="number" value={newRes.quantity} onChange={e => setNewRes(p => ({ ...p, quantity: +e.target.value }))} /></div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div><Label>Location</Label><Input value={newRes.location} onChange={e => setNewRes(p => ({ ...p, location: e.target.value }))} /></div>
                  {newRes.category === 'food' && <div><Label>Expiry/Shelf Life</Label><Input type="text" placeholder="e.g. 12 hours" value={newRes.expiry} onChange={e => setNewRes(p => ({ ...p, expiry: e.target.value }))} /></div>}
                </div>
                <Button variant="hero" className="w-full" onClick={handleAdd}>Post Donation</Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>
        
        <div className="mb-8 p-6 rounded-xl bg-white dark:bg-slate-900 text-blue-700 dark:text-blue-400 flex items-center justify-center text-center shadow-xl">
          <p className="italic font-bold text-xl">&quot;{quote}&quot;</p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          {[
            { label: 'Total Donated', value: totalDonated, icon: Package },
            { label: 'Claimed', value: claimed, icon: Heart },
            { label: 'Certificates', value: myCerts.length, icon: Award },
            { label: 'Impact Score', value: totalDonated * 10, icon: TrendingUp },
          ].map(s => (
            <div key={s.label} className="bg-white dark:bg-slate-900 p-6 rounded-xl text-slate-900 dark:text-white shadow-xl">
              <s.icon className="w-6 h-6 text-blue-600 dark:text-blue-400 mb-3" />
              <div className="text-3xl font-display font-bold"><CountUp end={s.value as number} /></div>
              <p className="text-sm font-semibold text-slate-500 dark:text-slate-400">{s.label}</p>
            </div>
          ))}
        </div>

        <div className="flex gap-4 mb-6 border-b border-white/20 pb-2">
          <button className={`pb-2 px-2 text-lg font-bold transition-colors ${activeTab === 'overview' ? 'border-b-4 border-white text-white' : 'text-white/60 hover:text-white'}`} onClick={() => setActiveTab('overview')}>Overview</button>
          <button className={`pb-2 px-2 text-lg font-bold transition-colors ${activeTab === 'food' ? 'border-b-4 border-white text-white' : 'text-white/60 hover:text-white'}`} onClick={() => setActiveTab('food')}>Food Outlet</button>
        </div>

        {activeTab === 'overview' && (
          <div className="grid md:grid-cols-2 gap-6">
            <div className="bg-white dark:bg-slate-900 text-slate-900 dark:text-white rounded-xl shadow-xl p-6">
              <h2 className="font-display text-lg font-semibold mb-4">My Donations</h2>
              {myResources.length === 0 ? <p className="text-sm text-muted-foreground">No donations yet.</p> : (
                <div className="space-y-3">
                  {myResources.map(r => (
                    <div key={r.id} className="flex items-center justify-between p-3 rounded-lg bg-slate-50 dark:bg-slate-800">
                      <div><p className="font-medium text-sm">{r.title}</p><p className="text-xs text-muted-foreground">{r.quantity} {r.unit}</p></div>
                      <span className={`text-xs px-2 py-1 rounded-full ${r.status === 'available' ? 'bg-success/10 text-success' : 'bg-warning/10 text-warning'}`}>{r.status}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="space-y-6">
              <div className="bg-white dark:bg-slate-900 text-slate-900 dark:text-white rounded-xl shadow-xl p-6">
                <h2 className="font-display text-lg font-semibold mb-4">Suggested Campaigns</h2>
                {suggestedCampaigns.map(p => (
                  <div key={p.id} className="p-3 rounded-lg bg-slate-50 dark:bg-slate-800 mb-2">
                    <p className="text-sm font-medium">{p.ngoName}</p>
                    <p className="text-xs text-muted-foreground line-clamp-2">{p.title}: {p.content}</p>
                  </div>
                ))}
              </div>
              <div className="bg-white dark:bg-slate-900 text-slate-900 dark:text-white rounded-xl shadow-xl p-6">
                <h2 className="font-display text-lg font-semibold mb-4 flex items-center gap-2"><FileText className="w-5 h-5" /> Certificates</h2>
                <Button variant="secondary" className="bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-white hover:bg-slate-200 dark:hover:bg-slate-700" size="sm" onClick={generateCertificate} className="mb-3">Generate Certificate</Button>
                {myCerts.map(c => (
                  <div key={c.id} className="p-3 rounded-lg bg-slate-50 dark:bg-slate-800 mb-2">
                    <p className="text-sm font-medium">{c.description}</p>
                    <p className="text-xs text-muted-foreground">{c.issuedAt.toLocaleDateString()}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'food' && (
          <div className="bg-white dark:bg-slate-900 text-slate-900 dark:text-white rounded-xl shadow-xl p-6 min-h-[400px]">
            <h2 className="font-display text-lg font-semibold mb-4">Food Outlet</h2>
            <div className="flex items-center justify-between bg-warning/10 text-warning px-4 py-3 rounded-lg mb-6 text-sm">
              <p>Items posted here will be immediately matched with active NGOs for pickup.</p>
              <Button size="sm" onClick={() => { setShowAdd(true); setNewRes(p => ({ ...p, category: 'food' })); }}>Post Food</Button>
            </div>
            
            <div className="space-y-4">
              {myResources.filter(r => r.category === 'food').map(r => (
                <div key={r.id} className="p-4 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 flex justify-between items-center">
                  <div>
                    <h3 className="font-semibold text-lg">{r.title}</h3>
                    <p className="text-sm font-medium text-slate-500">{r.quantity} {r.unit} • Loc: {r.location}</p>
                    <p className="text-xs text-muted-foreground mt-1">Status: <span className="font-medium">{r.status.toUpperCase()}</span></p>
                  </div>
                  {r.status !== 'available' && (
                    <div className="text-right">
                      <p className="text-xs font-medium text-slate-500">Claimed By: <span className="text-foreground font-semibold">{r.claimedByName}</span></p>
                      <Button variant="secondary" className="bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-white hover:bg-slate-200 dark:hover:bg-slate-700" size="sm" className="mt-2" onClick={() => toast.info('Fetching tracking status...')}>Track Pickup</Button>
                    </div>
                  )}
                </div>
              ))}
              {myResources.filter(r => r.category === 'food').length === 0 && <p className="text-muted-foreground text-sm">No food resources posted yet.</p>}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
