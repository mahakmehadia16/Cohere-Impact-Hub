import { useEffect, useRef, useState } from 'react';
import { Navbar } from '@/components/Navbar';
import { useAppStore, EventPost } from '@/lib/store';
import { Button } from '@/components/ui/button';
import { DollarSign, UserPlus, X, Calendar } from 'lucide-react';
import { toast } from 'sonner';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

export default function MapPage() {
  const mapRef = useRef<HTMLDivElement>(null);
  const mapInstance = useRef<any>(null);
  const { ngos, resources, events, currentUser, applyToEvent, donateToEvent } = useAppStore();
  const [selectedEvent, setSelectedEvent] = useState<EventPost | null>(null);

  useEffect(() => {
    if (!mapRef.current || mapInstance.current) return;

    const map = L.map(mapRef.current!, { scrollWheelZoom: true }).setView([20.5, 78.9], 5);
    mapInstance.current = map;

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '© OpenStreetMap contributors',
    }).addTo(map);

    const eventIcon = L.divIcon({
      html: `<div style="background:hsl(153,60%,40%);width:36px;height:36px;border-radius:50%;display:flex;align-items:center;justify-content:center;color:white;font-weight:bold;font-size:14px;border:3px solid white;box-shadow:0 0 20px hsl(153,60%,40%);animation:pulse 2s infinite, float 4s ease-in-out infinite;">E</div>`,
      className: 'event-marker bg-transparent', iconSize: [36, 36], iconAnchor: [18, 18],
    });

    // Show events happening next 7 days or right now
    const now = Date.now();
    const in7Days = now + 7 * 24 * 60 * 60 * 1000;
    
    const upcomingEvents = events.filter(e => {
      const time = e.date.getTime();
      return e.status === 'upcoming' && time >= now - 86400000 && time <= in7Days;
    });

    upcomingEvents.forEach(evt => {
      const parentNgo = ngos.find(n => n.id === evt.ngoId);
      if (parentNgo) {
        // Jiggle coords slightly so they don't exactly overlap with NGO marker
        const lat = parentNgo.lat + (Math.random() - 0.5) * 0.1;
        const lng = parentNgo.lng + (Math.random() - 0.5) * 0.1;
        
        L.marker([lat, lng], { icon: eventIcon })
          .addTo(map)
          .on('click', () => setSelectedEvent(evt));
      }
    });

    return () => {
      if (mapInstance.current) {
        mapInstance.current.remove();
        mapInstance.current = null;
      }
    };
  }, [events, ngos]); // omitting resources to simplify. If resources are needed later, they can be added back.

  const handleVolunteer = () => {
    if (!currentUser) { toast.error('Please login'); return; }
    if (!selectedEvent) return;
    if (selectedEvent.applicants.includes(currentUser.id)) { toast.info('Already applied'); return; }
    applyToEvent(selectedEvent.id, currentUser.id);
    toast.success('Successfully applied to volunteer!');
    setSelectedEvent(null);
  };

  const handleDonate = () => {
    if (!currentUser) { toast.error('Please login'); return; }
    if (!selectedEvent) return;
    donateToEvent(selectedEvent.id);
    toast.success('Donation initiated successfully!');
    setSelectedEvent(null);
  };

  return (
    <div className="min-h-screen bg-neutral-950 relative overflow-hidden flex flex-col">
      <Navbar />
      <div className="absolute top-0 inset-x-0 h-48 bg-gradient-to-b from-primary/30 via-primary/5 to-transparent pointer-events-none z-10" />
      <div className="pt-24 z-20 flex-none px-4 md:px-8 mb-6 pointer-events-none">
        <div className="container mx-auto">
          <div className="glass-card-elevated p-6 md:p-8 max-w-xl border-primary/20 bg-background/60 pointer-events-auto">
            <h1 className="font-display text-3xl md:text-4xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-primary to-accent mb-2">Live Impact Map</h1>
            <p className="text-sm md:text-base text-muted-foreground mb-4">Discover verified events happening right now or in the next 7 days across the nation.</p>
            <div className="flex gap-4">
              <span className="flex items-center gap-2 text-xs font-semibold px-3 py-1.5 rounded-full bg-primary/10 text-primary border border-primary/20 shadow-sm"><span className="w-2.5 h-2.5 rounded-full bg-primary animate-pulse inline-block" /> Active Events Found</span>
            </div>
          </div>
        </div>
      </div>
      <div className="flex-1 relative z-0 mx-4 md:mx-8 mb-8 rounded-2xl overflow-hidden border-2 border-primary/20 shadow-2xl shadow-primary/10">
        <div ref={mapRef} className="w-full h-[600px] md:h-[70vh] bg-slate-100 dark:bg-slate-900" />
      </div>

      {/* OVERLAY FOR EVENT ACTIONS */}
      {selectedEvent && (
        <div className="absolute inset-x-0 bottom-0 z-50 p-4 md:p-8 flex justify-center pointer-events-none">
          <div className="glass-card p-6 w-full max-w-lg mb-8 pointer-events-auto relative shadow-2xl animate-in slide-in-from-bottom-5">
            <button className="absolute top-4 right-4 text-muted-foreground hover:text-foreground" onClick={() => setSelectedEvent(null)}>
              <X className="w-5 h-5"/>
            </button>
            <h2 className="text-2xl font-bold font-display mb-1">{selectedEvent.title}</h2>
            <p className="text-sm font-medium text-primary mb-3">Host: {selectedEvent.ngoName}</p>
            
            <div className="flex gap-4 text-xs text-muted-foreground mb-4">
              <span className="flex items-center gap-1"><Calendar className="w-4 h-4"/> {selectedEvent.date.toLocaleDateString()}</span>
              <span className="uppercase font-semibold tracking-wider bg-primary/20 text-primary px-2 py-0.5 rounded">Upcoming</span>
            </div>
            
            <p className="text-sm leading-relaxed mb-6">{selectedEvent.content}</p>
            
            <div className="flex gap-3">
              <Button className="flex-1" variant="hero" onClick={handleVolunteer}>
                <UserPlus className="w-4 h-4 mr-2"/> Volunteer
              </Button>
              <Button className="flex-1" variant="outline" onClick={handleDonate}>
                <DollarSign className="w-4 h-4 mr-2"/> Donate
              </Button>
              <Button className="flex-1 bg-muted/50 text-foreground" variant="ghost" onClick={() => window.location.href = '/feed'}>
                View Post
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
