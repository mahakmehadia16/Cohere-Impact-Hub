import { useState } from 'react';
import { motion } from 'framer-motion';
import { Shield, Package, Users, Camera, FileText, MessageSquare, Lightbulb, CheckCircle } from 'lucide-react';
import { Navbar } from '@/components/Navbar';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { useAppStore } from '@/lib/store';
import { toast } from 'sonner';

const QUOTES = [
  "Alone we can do so little; together we can do so much. – Helen Keller",
  "Great things are done by a series of small things brought together. – Vincent Van Gogh",
  "There is no power for change greater than a community discovering what it cares about. – Margaret J. Wheatley",
  "The greatness of a community is most accurately measured by the compassionate actions of its members. – Coretta Scott King"
];

export default function NGODashboard() {
  const { currentUser, ngos, resources, volunteerApps, updateVolunteerStatus, addProof, proofs, claimResource,
    events, addEvent, certificates, issueCertificate, collaborations, acceptCollaboration, declineCollaboration, sendChatMessage } = useAppStore();
  const [showProof, setShowProof] = useState(false);
  const [proof, setProof] = useState({ description: '', location: '', imageUrl: '' });
  const [showPost, setShowPost] = useState(false);
  const [newPost, setNewPost] = useState('');
  const [postType, setPostType] = useState<'campaign' | 'need' | 'update'>('update');
  const [chatMessage, setChatMessage] = useState('');
  const [claimDialog, setClaimDialog] = useState<string | null>(null);
  const [claimPledge, setClaimPledge] = useState('');
  const [quote] = useState(() => QUOTES[Math.floor(Math.random() * QUOTES.length)]);

  if (!currentUser) return null;

  const myNGO = ngos.find(n => n.userId === currentUser.id);
  if (!myNGO) return (
    <div className="min-h-screen bg-gradient-to-br from-background via-muted/20 to-primary/5">
      <Navbar />
      <div className="container mx-auto px-4 pt-24 text-center">
        <p className="text-muted-foreground">NGO profile not found.</p>
      </div>
    </div>
  );

  const isVerified = myNGO.status === 'verified';
  const myApplicants = volunteerApps.filter(a => a.ngoId === myNGO.id);
  const claimedResources = resources.filter(r => r.claimedById === myNGO.id);
  const availableResources = resources.filter(r => r.status === 'available');
  const myProofs = proofs.filter(p => p.ngoId === myNGO.id);
  const myPosts = events.filter(p => p.ngoId === myNGO.id);
  const myCollabs = collaborations.filter(c => c.requestorId === myNGO.id || c.targetId === myNGO.id);

  const handleClaim = async (resource: any) => {
    if (!isVerified) { toast.error('Only verified NGOs can claim'); return; }
    if (!claimPledge.trim()) { toast.error('Please specify where this will be donated'); return; }
    
    try {
      const res = await fetch('/api/claims', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ resourceId: resource.id, ngoId: myNGO.id, pledge: claimPledge, lat: resource.lat, lng: resource.lng })
      });
      const data = await res.json();
      
      claimResource(resource.id, myNGO.id, myNGO.name);
      toast.success(`Claimed successfully! Pickup ID: ${data.pickupId}`);
      setClaimDialog(null);
      setClaimPledge('');
    } catch(e) {
      toast.error('Failed to claim resource via API');
    }
  };

  const handleProof = async () => {
    if (!proof.description) { toast.error("Description required"); return; }
    
    // Strict GPS Capture
    if (!navigator.geolocation) { toast.error("GPS not supported by your browser"); return; }
    
    toast.info("Capturing GPS coordinates...", { id: "gps-toast" });
    navigator.geolocation.getCurrentPosition(async (pos) => {
      const explicitLat = pos.coords.latitude;
      const explicitLng = pos.coords.longitude;
      
      try {
        const res = await fetch('/api/proofs/upload', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ ngoId: myNGO.id, explicitLat, explicitLng, contentUrl: proof.imageUrl || 'camera-capture.jpg' })
        });
        const data = await res.json();
        if (data.error) throw new Error(data.error);

        addProof({ ngoId: myNGO.id, ngoName: myNGO.name, imageUrl: proof.imageUrl || 'https://via.placeholder.com/400', location: `${explicitLat.toFixed(4)}, ${explicitLng.toFixed(4)}`, timestamp: new Date(data.timestamp), description: proof.description });
        toast.success(data.msg || 'Secure Proof submitted!', { id: "gps-toast" });
        setShowProof(false);
        setProof({ description: '', location: '', imageUrl: '' });
      } catch(e: any) {
        toast.error(e.message || "GPS API Verification Failed", { id: "gps-toast" });
      }
    }, (error) => {
      toast.error(`GPS Error: ${error.message} - No manual entries allowed.`, { id: "gps-toast" });
    });
  };

  const handlePost = () => {
    if (!isVerified) { toast.error('Only verified NGOs can post'); return; }
    addEvent({ ngoId: myNGO.id, ngoName: myNGO.name, title: 'New Event', content: newPost, location: myNGO.location, date: new Date(Date.now() + 86400000 * 7), status: 'upcoming' });
    toast.success('Posted!');
    setShowPost(false);
    setNewPost('');
  };

  return (
    <div className="min-h-screen bg-emerald-600 dark:bg-emerald-900 text-white">
      <Navbar />
      <div className="container mx-auto px-4 pt-24 pb-12">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-emerald-500 to-emerald-700 flex items-center justify-center text-white shadow-lg font-display font-bold text-lg pointer-events-none">{myNGO.name[0]}</div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="font-display text-2xl font-bold">{myNGO.name}</h1>
                {isVerified ? (
                  <span className="inline-flex items-center gap-1 text-xs px-2 py-1 rounded-full bg-success/10 text-success"><Shield className="w-3 h-3" /> Verified</span>
                ) : (
                  <span className="inline-flex items-center gap-1 text-xs px-2 py-1 rounded-full bg-warning/10 text-warning">Pending Verification</span>
                )}
              </div>
              <p className="text-base text-white/90 font-medium">{myNGO.location}</p>
            </div>
          </div>
          <div className="flex gap-2">
            <Dialog open={showPost} onOpenChange={setShowPost}>
              <DialogTrigger asChild><Button variant="outline" size="sm" disabled={!isVerified} className="bg-white text-emerald-900 hover:bg-emerald-50 border-none shadow-md"><MessageSquare className="w-4 h-4 mr-1" /> Post</Button></DialogTrigger>
              <DialogContent>
                <DialogHeader><DialogTitle>Create Post</DialogTitle></DialogHeader>
                <div className="space-y-4 mt-4">
                  <Textarea value={newPost} onChange={e => setNewPost(e.target.value)} placeholder="Share update..." rows={3} />
                  <div className="flex gap-2 invisible h-0">
                  </div>
                  <Button variant="hero" className="w-full" onClick={handlePost}>Publish</Button>
                </div>
              </DialogContent>
            </Dialog>
            <Dialog open={showProof} onOpenChange={setShowProof}>
              <DialogTrigger asChild><Button variant="hero" size="sm" className="bg-emerald-800 text-white hover:bg-emerald-700 border-none shadow-md"><Camera className="w-4 h-4 mr-1" /> Upload Proof</Button></DialogTrigger>
              <DialogContent>
                <DialogHeader><DialogTitle>Upload Secure Impact Proof</DialogTitle></DialogHeader>
                <div className="space-y-4 mt-4 text-sm text-muted-foreground">
                  <p className="bg-warning/10 text-warning p-2 rounded text-xs border border-warning/20">
                    <Shield className="w-3 h-3 inline mr-1" /> STRICT RULE: Location will be auto-captured via GPS. Manual entry disabled. 24-hr delay results in auto-flag.
                  </p>
                  <div><Label>Operation Description</Label><Input value={proof.description} onChange={e => setProof(p => ({ ...p, description: e.target.value }))} placeholder="Distributed 50 boxes at station..." /></div>
                  <div><Label>Camera Image URL</Label><Input value={proof.imageUrl} onChange={e => setProof(p => ({ ...p, imageUrl: e.target.value }))} placeholder="https://..." /></div>
                  <Button variant="hero" className="w-full" onClick={handleProof}>Capture GPS & Submit</Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        {!isVerified && (
          <div className="bg-white dark:bg-slate-900 p-4 mb-6 rounded-xl border-l-4 border-l-yellow-500 shadow-xl">
            <p className="text-sm text-slate-800 dark:text-slate-200 font-bold">⏳ Your NGO is pending admin verification. Some features are restricted.</p>
          </div>
        )}

        <div className="mb-8 p-6 rounded-xl bg-white dark:bg-slate-900 text-emerald-700 dark:text-emerald-400 shadow-xl flex items-center justify-center text-center">
          <p className="italic font-medium text-lg">&quot;{quote}&quot;</p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <div className="bg-white dark:bg-slate-900 p-6 rounded-xl text-slate-900 dark:text-white shadow-xl"><Package className="w-5 h-5 text-emerald-500 mb-2" /><div className="text-2xl font-display font-bold text-emerald-100">{claimedResources.length}</div><p className="text-sm font-semibold text-slate-500 dark:text-slate-400">Resources Claimed</p></div>
          <div className="bg-white dark:bg-slate-900 p-6 rounded-xl text-slate-900 dark:text-white shadow-xl"><Users className="w-5 h-5 text-emerald-500 mb-2" /><div className="text-2xl font-display font-bold text-emerald-100">{myApplicants.length}</div><p className="text-sm font-semibold text-slate-500 dark:text-slate-400">Volunteers</p></div>
          <div className="bg-white dark:bg-slate-900 p-6 rounded-xl text-slate-900 dark:text-white shadow-xl"><Camera className="w-5 h-5 text-emerald-500 mb-2" /><div className="text-2xl font-display font-bold text-emerald-100">{myProofs.length}</div><p className="text-sm font-semibold text-slate-500 dark:text-slate-400">Proofs Submitted</p></div>
          <div className="bg-white dark:bg-slate-900 p-6 rounded-xl text-slate-900 dark:text-white shadow-xl"><MessageSquare className="w-5 h-5 text-emerald-500 mb-2" /><div className="text-2xl font-display font-bold text-emerald-100">{myPosts.length}</div><p className="text-sm font-semibold text-slate-500 dark:text-slate-400">Posts</p></div>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          {/* Collaborations Section */}
          <div className="glass-card p-6 md:col-span-3">
            <h2 className="font-display text-lg font-semibold mb-4">Collaborations ({myCollabs.length})</h2>
            <div className="grid md:grid-cols-2 gap-4">
              {myCollabs.map(collab => {
                const isTarget = collab.targetId === myNGO.id;
                const partnerName = isTarget ? collab.requestorName : collab.targetName;
                
                return (
                  <div key={collab.id} className="p-4 rounded-xl border border-border bg-card shadow-sm">
                    <div className="flex justify-between items-start mb-2">
                      <div>
                        <h3 className="font-semibold text-sm">Partner: {partnerName}</h3>
                        <p className="text-sm font-semibold text-slate-500 dark:text-slate-400">Event ID: {collab.eventId}</p>
                      </div>
                      <span className={`text-xs px-2 py-1 rounded-full ${
                        collab.status === 'accepted' ? 'bg-success/20 text-success' :
                        collab.status === 'pending' ? 'bg-warning/20 text-warning' : 'bg-destructive/20 text-destructive'
                      }`}>
                        {collab.status.toUpperCase()}
                      </span>
                    </div>

                    {collab.status === 'pending' && isTarget && (
                      <div className="flex gap-2 mt-4 pt-4 border-t border-border">
                        <Button size="sm" onClick={() => { acceptCollaboration(collab.id); toast.success('Accepted'); }}>Accept</Button>
                        <Button size="sm" variant="destructive" onClick={() => { declineCollaboration(collab.id); toast.error('Declined'); }}>Decline</Button>
                      </div>
                    )}
                    {collab.status === 'pending' && !isTarget && (
                      <p className="text-xs text-muted-foreground mt-4 pt-4 border-t border-border">Waiting for response...</p>
                    )}

                    {collab.status === 'accepted' && (
                      <div className="mt-4 pt-4 border-t border-border">
                        <Dialog>
                          <DialogTrigger asChild>
                            <Button size="sm" variant="outline" className="w-full"><MessageSquare className="w-4 h-4 mr-2"/> Open Chat</Button>
                          </DialogTrigger>
                          <DialogContent className="max-w-xl h-[600px] flex flex-col">
                            <DialogHeader>
                              <DialogTitle>Chat with {partnerName}</DialogTitle>
                            </DialogHeader>
                            <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-muted/10 rounded-md border border-border/50">
                              {collab.messages.map(msg => (
                                <div key={msg.id} className={`flex ${msg.senderId === myNGO.id ? 'justify-end' : 'justify-start'}`}>
                                  <div className={`max-w-[80%] rounded-lg p-3 ${msg.senderId === myNGO.id ? 'bg-primary text-primary-foreground' : 'bg-muted'}`}>
                                    <p className="text-xs font-semibold mb-1 opacity-75">{msg.senderName}</p>
                                    <p className="text-sm">{msg.content}</p>
                                    <p className="text-[10px] text-right mt-1 opacity-50">{msg.createdAt.toLocaleTimeString()}</p>
                                  </div>
                                </div>
                              ))}
                              {collab.messages.length === 0 && <p className="text-center text-muted-foreground text-sm my-10">No messages yet. Send one to start!</p>}
                            </div>
                            <div className="flex gap-2 pt-2">
                              <Input 
                                placeholder="Type your message..." 
                                value={chatMessage} 
                                onChange={e => setChatMessage(e.target.value)} 
                                onKeyDown={e => {
                                  if (e.key === 'Enter' && chatMessage.trim()) {
                                    sendChatMessage(collab.id, myNGO.id, myNGO.name, chatMessage.trim());
                                    setChatMessage('');
                                  }
                                }}
                              />
                              <Button onClick={() => {
                                if (chatMessage.trim()) {
                                  sendChatMessage(collab.id, myNGO.id, myNGO.name, chatMessage.trim());
                                  setChatMessage('');
                                }
                              }}>Send</Button>
                            </div>
                          </DialogContent>
                        </Dialog>
                      </div>
                    )}
                  </div>
                );
              })}
              {myCollabs.length === 0 && <p className="text-sm text-muted-foreground md:col-span-2">No collaborations yet.</p>}
            </div>
          </div>

          {/* Available Resources */}
          <div className="bg-white dark:bg-slate-900 text-slate-900 dark:text-white rounded-xl shadow-xl p-6">
            <h2 className="font-display text-lg font-semibold mb-4">Available Resources ({availableResources.length})</h2>
            <div className="space-y-3 max-h-80 overflow-y-auto">
              {availableResources.map(r => (
                <div key={r.id} className="flex items-center justify-between p-4 rounded-lg bg-slate-50 dark:bg-slate-800">
                  <div><p className="font-medium text-sm">{r.title}</p><p className="text-sm font-semibold text-slate-500 dark:text-slate-400">{r.quantity} {r.unit} · {r.location}</p></div>
                  <Dialog open={claimDialog === r.id} onOpenChange={(open) => setClaimDialog(open ? r.id : null)}>
                    <DialogTrigger asChild>
                      <Button size="sm" disabled={!isVerified}>Claim</Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader><DialogTitle>Claim Resource: {r.title}</DialogTitle></DialogHeader>
                      <div className="space-y-4 mt-4">
                        <div className="bg-muted p-3 rounded-lg text-sm text-muted-foreground">
                          <p><strong>Quantity:</strong> {r.quantity} {r.unit}</p>
                          <p><strong>Location:</strong> {r.location} (Exact GPS provided upon claim)</p>
                        </div>
                        <div>
                          <Label>Donation Pledge (Required)</Label>
                          <p className="text-xs text-muted-foreground mb-2">Where exactly will this be distributed? You must upload proof within 24hrs of claiming.</p>
                          <Input value={claimPledge} onChange={e => setClaimPledge(e.target.value)} placeholder="e.g. Slum area near Andheri East station" />
                        </div>
                        <Button variant="hero" className="w-full" onClick={() => handleClaim(r)}>Confirm Claim & Get Pickup ID</Button>
                      </div>
                    </DialogContent>
                  </Dialog>
                </div>
              ))}
            </div>
          </div>

          {/* Volunteer Applications */}
          <div className="bg-white dark:bg-slate-900 text-slate-900 dark:text-white rounded-xl shadow-xl p-6">
            <h2 className="font-display text-lg font-semibold mb-4 bg-primary/10 text-primary p-2 rounded-lg inline-block"><Shield className="w-4 h-4 inline mr-2"/> Participation Verification</h2>
            <div className="space-y-3">
              {myApplicants.map(a => (
                <div key={a.id} className="p-3 rounded-lg bg-muted/30">
                  <div className="flex items-center justify-between mb-2">
                    <p className="font-medium text-sm">{a.volunteerName}</p>
                    <span className={`text-xs px-2 py-1 rounded-full ${
                      a.status === 'accepted' ? 'bg-success/10 text-success' :
                      a.status === 'applied' ? 'bg-info/10 text-info' : 'bg-muted text-muted-foreground'
                    }`}>{a.status}</span>
                  </div>
                  <p className="text-xs text-muted-foreground mb-2">{a.role} · Skills: {a.skills.join(', ')}</p>
                  {a.status === 'applied' && (
                    <div className="flex gap-2">
                      <Button size="sm" onClick={() => { updateVolunteerStatus(a.id, 'accepted'); toast.success('Accepted!'); }}>
                        <CheckCircle className="w-3 h-3 mr-1" /> Accept
                      </Button>
                    </div>
                  )}
                  {a.status === 'accepted' && (
                    <div className="flex gap-2 mt-2 pt-2 border-t border-border/50">
                      <Button size="sm" variant="hero" onClick={() => { 
                        updateVolunteerStatus(a.id, 'completed'); 
                        toast.success('Participant Verified! They can now download their certificate.'); 
                      }}>
                        <Shield className="w-3 h-3 mr-1" /> Verify Participation
                      </Button>
                    </div>
                  )}
                </div>
              ))}
              {myApplicants.length === 0 && <p className="text-sm text-muted-foreground">No volunteer applications yet.</p>}
            </div>
          </div>

          {/* Proofs */}
          <div className="bg-white dark:bg-slate-900 text-slate-900 dark:text-white rounded-xl shadow-xl p-6">
            <h2 className="font-display text-lg font-semibold mb-4">Impact Proofs</h2>
            {myProofs.length === 0 ? <p className="text-sm text-muted-foreground">No proofs uploaded yet.</p> : (
              <div className="space-y-3">
                {myProofs.map(p => (
                  <div key={p.id} className="p-3 rounded-lg bg-muted/30">
                    <p className="font-medium text-sm">{p.description}</p>
                    <p className="text-sm font-semibold text-slate-500 dark:text-slate-400">{p.location} · {p.timestamp.toLocaleDateString()}</p>
                    <span className={`text-xs px-2 py-1 rounded-full mt-1 inline-block ${p.status === 'verified' ? 'bg-success/10 text-success' : 'bg-warning/10 text-warning'}`}>{p.status}</span>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Suggestions */}
          <div className="bg-white dark:bg-slate-900 text-slate-900 dark:text-white rounded-xl shadow-xl p-6">
            <h2 className="font-display text-lg font-semibold mb-4 flex items-center gap-2"><Lightbulb className="w-5 h-5 text-warning" /> Suggestions</h2>
            <div className="space-y-3">
              <div className="p-3 rounded-lg bg-muted/30"><p className="text-sm font-medium">Partner with local restaurants</p><p className="text-sm font-semibold text-slate-500 dark:text-slate-400">Connect with nearby food donors</p></div>
              <div className="p-3 rounded-lg bg-muted/30"><p className="text-sm font-medium">Launch a clothing drive</p><p className="text-sm font-semibold text-slate-500 dark:text-slate-400">Winter is approaching — start collecting</p></div>
              <div className="p-3 rounded-lg bg-muted/30"><p className="text-sm font-medium">Recruit tech volunteers</p><p className="text-sm font-semibold text-slate-500 dark:text-slate-400">Skill-based volunteers available</p></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
